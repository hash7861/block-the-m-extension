🅾️ Ohio State Hate Week Browser Extension
“Block The M” – A Chrome & Edge Extension

This extension automatically crosses out every letter “M” (uppercase or lowercase) on any webpage using a bold scarlet “X”.
Perfect for Hate Week, scrolling ESPN, or browsing that school up north’s website.

🚀 Features

Injects a content script into any active tab

Wraps every M/m in a styled span

Draws a centered, oversized OSU scarlet X over each M

Works on Chrome and Microsoft Edge

Simple one-click popup UI

🛠️ Built With

JavaScript (Manifest V3 API)

Chrome Scripting API (chrome.scripting.executeScript)

DOM TreeWalker

Custom CSS for dynamic injected styling

📦 Installation (Developer Mode)

Clone this repo

Open chrome://extensions

Enable Developer Mode

Click Load unpacked

Select the project folder

✊ Why I built this

Because Hate Week is sacred.
Because disrespect must be delivered.
And because writing a Chrome extension in under an hour is surprisingly fun.

🏈 Go Bucks